public class Shape {
    double getArea(){return 0.0;}
    double getPerimeter(){return 0.0;}
    public String toString(){
        return "shape";
    }
}
