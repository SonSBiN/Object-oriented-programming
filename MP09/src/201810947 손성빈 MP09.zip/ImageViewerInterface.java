public interface ImageViewerInterface {
    String getName();
    void show(String fileName);
    String getExtension();
}
